package hw.sem4.task2;

public class Main {
    public static void main(String[] args) {
        DoubleCube dc = new DoubleCube();
        System.out.println(dc);
    }
}
